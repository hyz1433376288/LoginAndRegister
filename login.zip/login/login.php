<?php
$host = "127.0.0.1";
$dbuser = "root";
$dbpwd = "root";
$dbname = "php10days";

//连接mysql数据库
$db = new mysqli($host,$dbuser,$dbpwd,$dbname);
if($db->connect_errno <> 0){
    echo "数据库连接失败".mysqli_connect_error();
    exit;
}

$username = $_POST['username'];
$userpwd = $_POST['password'];
session_start();//开启session


if($username == $_COOKIE['username']){
    header("location:http://oj.houyz.cn/");
    exit();
}
$sql = "SELECT * FROM `login` WHERE name = '{$username}'";
$mysql_result = $db->query($sql);

$cnt = mysqli_num_rows($mysql_result);
if($cnt == 0){
    echo "没有这个人".$username;
    //进入出去页面
    //header("location:out.html");

}
else if ( $cnt == 1){
    //说明存在该用户
    $infoRow = $mysql_result->fetch_array(MYSQLI_ASSOC);
    //验证密码
    if(strcmp($userpwd,$infoRow['pwd']) == 0 ){
        setcookie('username',$username,time()+60,'/');//有效时长1分钟
        $_SESSION['username'] = $username;
        header("location:http://oj.houyz.cn/");
    }
    else {
        echo "密码错误";
//        sleep(3);
//        header("location:out.html");
    }
}

