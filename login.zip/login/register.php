<?php
$host = "127.0.0.1";
$dbuser = "root";
$dbpwd = "root";
$dbname = "php10days";

//连接mysql数据库
$db = new mysqli($host,$dbuser,$dbpwd,$dbname);
if($db->connect_errno <> 0){
    echo "数据库连接失败".mysqli_connect_error();
    exit;
}

$username = $_GET['username'];
$userpwd = $_GET['password'];
$userpwd2 = $_GET['password2'];

//查看该用户名是否被注册



    $sql = "SELECT * FROM `login` WHERE name = '{$username}'";
    $mysql_result = $db->query($sql);
    $cnt = mysqli_num_rows($mysql_result);
    echo $cnt;
    if($cnt == 0){
        //没有被注册
        //查看密码是否一致
        if(strcmp($userpwd,$userpwd2)==0){
            //创建改用户信息,自动登录，并设置cookie
            $sql = "INSERT into login (name,pwd) values ('{$username}','{$userpwd}')";
            $mysql_result=$db->query($sql);
            header("location:index.php");
        }
        else {
            echo "密码不同，请重新输入";

        }
    }
    else {
        echo "用户名".$username."已经被注册";

    }
    exit();
