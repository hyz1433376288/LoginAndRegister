<!DOCTYPE html>
<?php
    session_start();

    //cookie过期之前自动跳转
    if( strcmp( $_COOKIE['username'], $_SESSION['username']) == 0){
        header("location:http://oj.houyz.cn/");
    }
?>

<html>
<head>
	<meta charset="utf-8">
	<title>登陆测试</title>
</head>
<style type="text/css">
	body{
		margin: 0;
		background-color: white;
	}
	.w{
		max-width: 1000px;
		margin: 0 auto;
		padding: 100px;
		background-color: rgb(246,244,240);
		min-height: 1000px;
	}
	.content {
		width: 45%;
		height: auto;
		margin: 0 auto;
		border: #000000;
		border: whitesmoke;
		background-color: skyblue;
		padding: 30px;
	}
	.content form input{
		display: block;
		margin: 0 auto 10px;
		
		width: 250px;
		height: 20px;
		
	}
	form span{
		margin-left: 100px;
	}
	
	
</style>
<body>
	<div class="w">
		<div class="content">
			<form action="http://localhost/login/login.php" method="POST">
				<span>用户名</span><input  type="text" name="username"/>
				<span>密码</span><input  type="password" name="password" />
				<input style="width: 80px ;height: 45px;" type="submit" value="登陆" />
				<span style="font-size: 12px; float: right">还没有账号? 点击 <a href="register.html">注册</a></span>
			</form>

		</div>
	</div>

</body>
</html>